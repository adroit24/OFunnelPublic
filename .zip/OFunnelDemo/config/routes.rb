OFunnel::Application.routes.draw do

  resources :users
  resources :requests
  resources :groups
  namespace :admin do
    resources :groups
  end

  get "/linkedin/authorize_with_likedin" => "linkedin#authorize_with_likedin", :as => :authorize_with_likedin
  get "/linkedin/linkedin_authorization_callback" => "linkedin#linkedin_authorization_callback"
  match 'search_connections' => "linkedin#search_connections", :as => :search_connections
  match 'linkedin_search' => "linkedin#linkedin_search", :as => :linkedin_search
  match 'connections/:id/:status' => "linkedin#connections", :as => :connections
  match 'get_people_in_company' => "linkedin#get_people_in_company", :as => :get_people_in_company
  match 'get_people_for_query' => "linkedin#get_people_for_query", :as => :get_people_for_query
  match 'multiple_company_search' => "linkedin#multiple_company_search", :as => :multiple_company_search
  match 'multiple_company_search_results' => "linkedin#multiple_company_search_results", :as => :multiple_company_search_results

  get "/google/authorize_with_google" => "google#authorize_with_google", :as => :authorize_with_google
  get "/google/google_authorization_callback" => "google#google_authorization_callback"

  get "/facebook/authorize_with_facebook" => "facebook#authorize_with_facebook", :as => :authorize_with_facebook
  get "/facebook/facebook_authorization_callback" => "facebook#facebook_authorization_callback"

  get "/twitter/authorize_with_twitter" => "twitter#authorize_with_twitter"
  get "/twitter/twitter_authorization_callback" => "twitter#twitter_authorization_callback"
  match 'twitter_login' => "twitter#index", :as => :twitter_login
  match '/twitter/show/:id' => "twitter#show", :as => :twitter_show

  match 'new_open_request' => "requests#new_open_request", :as => :new_open_request
  match 'request_more_info/:id' => "requests#more_info", :as => :more_info
  match 'accept' => "requests#accept", :as => :accept
  match 'ignore' => "requests#ignore", :as => :ignore
  match 'update_request_info' => "requests#update_request_info", :as => :update_request_info

  match '/logout' => "users#logout", :as => :logout

  match '/group_members/:id' => "groups#members", :as => :group_members
  match '/add_group' => "groups#add", :as => :add_group
  match '/delete_group/:id' => "groups#delete", :as => :delete_group
  match '/add_member' => "groups#add_member", :as => :add_member
  match '/add_admin' => "groups#add_admin", :as => :add_admin
  match '/approve_membership/:status/:invite_id/:token' => "groups#approve_membership", :as => :approve_membership
  match '/groups/join/:invite_id/:token' => "groups#join", :as => :join_group
  match '/group_request' => "groups#group_request", :as => :group_request
  match '/search_group' => "groups#search_group", :as => :search_group
  match '/search_member_in_group' => "groups#search_member_in_group", :as => :search_member_in_group

  root :to => "linkedin#index"
  #root :to => "twitter#login_with_twitter"

  # The priority is based upon order of creation:
  # first created -> highest priority.

  # Sample of regular route:
  #   match 'products/:id' => 'catalog#view'
  # Keep in mind you can assign values other than :controller and :action

  # Sample of named route:
  #   match 'products/:id/purchase' => 'catalog#purchase', :as => :purchase
  # This route can be invoked with purchase_url(:id => product.id)

  # Sample resource route (maps HTTP verbs to controller actions automatically):
  #   resources :products

  # Sample resource route with options:
  #   resources :products do
  #     member do
  #       get 'short'
  #       post 'toggle'
  #     end
  #
  #     collection do
  #       get 'sold'
  #     end
  #   end

  # Sample resource route with sub-resources:
  #   resources :products do
  #     resources :comments, :sales
  #     resource :seller
  #   end

  # Sample resource route with more complex sub-resources
  #   resources :products do
  #     resources :comments
  #     resources :sales do
  #       get 'recent', :on => :collection
  #     end
  #   end

  # Sample resource route within a namespace:
  #   namespace :admin do
  #     # Directs /admin/products/* to Admin::ProductsController
  #     # (app/controllers/admin/products_controller.rb)
  #     resources :products
  #   end

  # You can have the root of your site routed with "root"
  # just remember to delete public/index.html.
  # root :to => 'welcome#index'

  # See how all your routes lay out with "rake routes"

  # This is a legacy wild controller route that's not recommended for RESTful applications.
  # Note: This route will make all actions in every controller accessible via GET requests.
  # match ':controller(/:action(/:id))(.:format)'
end
