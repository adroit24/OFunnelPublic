class UsersController < ApplicationController

  before_filter :check_current_user, :set_tab

  def show
    @id = params[:id]
    api_endpoint = "#{Settings.api_endpoints.GetUserProfileFromUserId}/#{@id}"
    response = Typhoeus.get(api_endpoint)
    @profile = {}
    if response.success? && !api_contains_error("GetUserProfileFromUserId", response)
      @profile = JSON.parse(response.response_body)["GetUserProfileFromUserIdResult"]
    else
      @profile["error"] = nil
      log_errors(response.return_message)
    end
  end

  def logout
    api_endpoint = "#{Settings.api_endpoints.Logout}"
    response = Typhoeus.post(api_endpoint, body: {
        userId: current_user_id
    })

    if response.success? && !api_contains_error("Logout", response)
      reset_session
    end

    redirect_to Settings.logout_redirect
  end

  protected

  def set_tab
    session[:selected_tab] = "users"
    session[:active_tab] = ""
  end
end
