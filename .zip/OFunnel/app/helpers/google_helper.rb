module GoogleHelper
end
