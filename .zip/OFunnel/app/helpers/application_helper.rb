module ApplicationHelper

  def is_tab_selected?(tab)
    session[:selected_tab] == tab ? "selected" : ""
  end

  def profile_pic_url
    profile_pic = current_user_profile[:profilePictureUrl]
    return profile_pic.blank? ? "/assets/user_photo.jpg" : "#{profile_pic}"
  end

  def user_name
    return current_user_profile.nil? ? "" : "#{current_user_profile[:firstName]} #{current_user_profile[:lastName]}"
  end

  def company_name
    return "#{current_user_profile[:companyName]}"
  end

  def job_title
    return "#{current_user_profile[:position]}"
  end

  def location
    return "#{current_user_profile[:location]["name"]}"
  end

  def skills
    skill_collection = current_user_profile[:skills]
    unless skill_collection.nil?
      skill_set = []
      skill_collection["values"].each do |skill_element|
        skill_set << skill_element["skill"]["name"]
      end
      return skill_set.join(', ')
    else
      return ""
    end
  end

  def request_id(request)
    id = request["requestId"]
    return id
  end

  def get_request_visibility(request)
    visibility = request["visibility"]
    return visibility
  end

  def get_visibility_tags(request)
    visibility_tags = request["RequestVisibilityTags"]
    return visibility_tags.to_json
  end

  def request_point(request)
    point = "5"
    return point
  end

  def request_outcome(request)
    status = request_status(request)
    return status
  end

  def request_status(request)
    status = request["status"]
    case status
      when "ACCEPTED"
        return "Accepted"
      when "PENDING"
        return "Pending"
      when "DECLINED"
        return "Declined"
      when "IGNORED"
        return "Ignored"
      when "REQUESTEDINFO"
        return "Requested More Info"
    end
  end

  def request_message(request)
    return request["content"]
  end

  def request_query(request)
    return request["querySearched"]
  end

  def for_user_name(request)
    return request["forUserName"]
  end

  def from_user_name(request)
    return request["fromUserName"]
  end

  def to_user_name(request)
    return request["toUserName"]
  end

  def for_user_id(request)
    return request["forUserId"].to_i
  end

  def from_user_id(request)
    return request["fromUserId"].to_i
  end

  def to_user_id(request)
    return request["toUserId"].to_i
  end

  def for_user_profile_url(request)
    profile_url = request["forUserProfileUrl"]
    return profile_url.blank? ? "#" : "#{profile_url}"
  end

  def from_user_profile_url(request)
    profile_url = request["fromUserProfileUrl"]
    return profile_url.blank? ? "#" : "#{profile_url}"
  end

  def to_user_profile_url(request)
    profile_url = request["toUserProfileUrl"]
    return profile_url.blank? ? "#" : "#{profile_url}"
  end

  def for_user_profile_pic(request)
    profile_pic = request["forUserProfilePicUrl"]
    return profile_pic.blank? ? "/assets/user_photo.jpg" : "#{profile_pic}"
  end

  def from_user_profile_pic(request)
    profile_pic = request["fromUserProfilePicUrl"]
    return profile_pic.blank? ? "/assets/user_photo.jpg" : "#{profile_pic}"
  end

  def to_user_profile_pic(request)
    profile_pic = request["toUserProfilePicUrl"]
    return profile_pic.blank? ? "/assets/user_photo.jpg" : "#{profile_pic}"
  end

  def for_user_company(request)
    company = request["forUserCompany"]
    return company == "false" ? "" : company
  end

  def from_user_company(request)
    company = request["fromUserCompany"]
    return company == "false" ? "" : company
  end

  def to_user_company(request)
    company = request["toUserCompany"]
    return company == "false" ? "" : company
  end

  def for_user_headline(request)
    headline = request["forUserHeadline"]
    return headline == "--" ? "" : headline
  end

  def from_user_headline(request)
    headline = request["fromUserHeadline"]
    return headline == "--" ? "" : headline
  end

  def to_user_headline(request)
    headline = request["toUserHeadline"]
    return headline == "--" ? "" : headline
  end

  def for_user_linkedin_id(request)
    headline = request["forUserLinkedInId"]
    return headline == "--" ? "" : headline
  end

  def from_user_linkedin_id(request)
    headline = request["fromUserLinkedInId"]
    return headline == "--" ? "" : headline
  end

  def to_user_linkedin_id(request)
    headline = request["toUserLinkedInId"]
    return headline == "--" ? "" : headline
  end

  def for_user_score(request)
    return request["forUserScore"]
  end

  def from_user_score(request)
    return request["fromUserScore"]
  end

  def to_user_score(request)
    return request["toUserScore"]
  end

  def is_for_user_score_exists(request)
    return request["forUserScore"].to_i > 0 ? true : false
  end

  def is_from_user_score_exists(request)
    return request["fromUserScore"].to_i > 0 ? true : false
  end

  def is_to_user_score_exists(request)
    return request["toUserScore"].to_i > 0 ? true : false
  end

  def is_open_request(request)
    return (request["toUserId"].to_i == -1 and request["forUserId"].to_i == -1) ? true : false
  end

  def is_for_user_exists(request)
    return (request["forUserId"].to_i == -1) ? false : true
  end

  def is_to_user_exists(request)
    return (request["toUserId"].to_i == -1) ? false : true
  end

  def forUserAccountType(request)
    request["forUserAccountType"]
  end

  def user_account_id(connection)
    connection["accountId"]
  end

  def user_profile_pic_url(connection)
    profile_pic = connection["profilePicUrl"]
    return profile_pic.blank? ? "/assets/user_photo.jpg" : "#{profile_pic}"
  end

  def user_connection_strength(connection)
    connection["connectionStrength"]
  end

  # Google related helper methods

  def google_email(connection)
    email_array = connection["gd$email"]
    unless email_array.nil? or email_array.blank?
      return email_array[0]["address"]
    end
  end

  def google_username(connection)
    title = connection["title"]
    return title.nil? ? "" : title["$t"]
  end

  def forUserGoogleAccountId(request)
    request["forUserAccountId"]
  end

  # Facebook related helper methods

  def connection_facebook_id(connection)
    return connection["id"]
  end

  def connection_facebook_name(connection)
    return connection["name"]
  end

  def connection_facebook_profile_url(connection)
    profile_url = connection["link"]
    return profile_url.blank? ? "#" : profile_url
  end

  def connection_facebook_profile_pic_url(connection)
    picture_hash = connection["picture"]
    unless picture_hash.nil?
      profile_pic_url = picture_hash["data"].blank? ? "/assets/user_photo.jpg" : picture_hash["data"]["url"]
    else
      profile_pic_url = "/assets/user_photo.jpg"
    end
    return profile_pic_url.blank? ? "/assets/user_photo.jpg" : "#{profile_pic_url}"
  end

  def connection_facebook_headline(connection)
    work_hash = connection["work"]
    unless work_hash.nil?
      work_hash = work_hash[0]
      company = work_hash["employer"].blank? ? "" : work_hash["employer"]["name"]
      position = work_hash["position"].blank? ? "" : work_hash["position"]["name"]
      if position.blank?
        headline = "#{company}"
      elsif company.blank?
      headline = "#{position}"
      else
        headline = "#{position}, #{company}"
      end
    else
      headline = ""
    end
    return headline
  end

  def forUserFacebookHeadline(request)
    request["forUserCompany"]
  end
end
