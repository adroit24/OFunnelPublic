class ApplicationController < ActionController::Base
  protect_from_forgery
  before_filter :user_tags, :initialize_ofunnel
  helper_method :current_user, :current_user_id, :current_user_profile, :current_user_score, :show_ofunnel_help, :check_google_session, :check_facebook_session
  rescue_from Exception, :with => :server_error if Rails.env.production?

  def server_error(exception)
    ExceptionNotifier::Notifier.exception_notification(request.env, exception).deliver
    redirect_to root_url and return
  end

  def current_user
    return session[:linkedin_id]
  end

  def set_current_user(linkedin_id)
    session[:linkedin_id] = linkedin_id
  end

  def current_user_id
    return session[:user_id]
  end

  def set_current_user_id(user_id)
    session[:user_id] = user_id
  end

  def current_user_profile
    return session[:profile]
  end

  def set_current_user_profile(profile)
    session[:profile] = profile
  end

  def current_user_score
    return session[:user_score]
  end

  def set_current_user_score(score)
    session[:user_score] = score
  end

  def set_show_ofunnel_help(flag)
    session[:show_help] = flag
  end

  # Commented due to bug#324
  #def show_ofunnel_help
  #  return session[:show_help]
  #end

  def user_tags
    if current_user
      if session[:user_tags].nil?
        get_tags_api_endpoint = "#{Settings.api_endpoints.GetUserTagsFromUserId}/#{current_user_id}"
        get_tags_response = nil

        hydra = Typhoeus::Hydra.hydra
        get_tags_request = Typhoeus::Request.new(get_tags_api_endpoint)
        hydra.queue get_tags_request
        get_tags_request.on_complete do |response|
          get_tags_response = response
        end
        hydra.run
        if get_tags_response.success? && !api_contains_error("GetUserTagsFromUserId", get_tags_response)
          tags = JSON.parse(get_tags_response.response_body)["GetUserTagsFromUserIdResult"]
          unless tags.nil?
            session[:user_tags] = tags["userTagsDetails"]
            @user_tags = session[:user_tags]
          else
            @user_tags = nil
          end
        else
          @user_tags = nil
        end
      else
        @user_tags = session[:user_tags]
      end
    end
  end

  def log_errors(error)
    api_endpoint = "#{Settings.api_endpoints.Addlogs}"
    response = Typhoeus.post(api_endpoint, body: { logInfo: error})
    if response.success?
      logger.error error
      return true
    else
      logger.error "Cannot log to Backend server"
      return false
    end
  end

  def check_current_user
    if session[:linkedin_id] == nil
      session[:return_to] = request.env['REQUEST_URI']
      redirect_to authorize_with_likedin_path and return
    end
  end

  def check_google_session
    session[:google_token].nil? ? false : true
  end

  def check_facebook_session
    session[:facebook_token].nil? ? false : true
  end

  def check_salesforce_session
    if session[:salesforce_token].nil?
      session[:return_to] = request.env['REQUEST_URI']
      redirect_to authorize_with_salesforce_path and return
    else
      return true
    end
  end

  def initialize_ofunnel
    session[:selected_connections] = session[:selected_connections].nil? ? {} : session[:selected_connections]
  end

  def clear_session
    set_current_user(nil)
    set_current_user_id(nil)
    set_current_user_score(nil)
    set_current_user_profile(nil)
  end

  def api_contains_error(api_name, api_response)
    begin
      api_name = api_name + "Result"
      api_response_body = JSON.parse(api_response.response_body)
      if api_response_body[api_name].blank?
        true
      elsif api_response_body[api_name]["error"].blank?
        false
      else
        log_errors(api_response_body[api_name]["error"])
        logger.error api_response_body[api_name]["error"]
        true
      end
    rescue Exception => e
      logger.error e
      return true
    end
  end

end
