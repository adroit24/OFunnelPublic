# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
OFunnel::Application.config.secret_token = '2759ed9d1b25c7dabcb8fa9828a9cb44917399dfe0c947693104e821fedf0f8684b4973c8dccd771273a2e9ea012b30a7729de4e55be6dd5a5e15ac076523c42'
