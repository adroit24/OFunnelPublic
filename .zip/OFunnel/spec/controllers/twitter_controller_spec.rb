require 'spec_helper'

describe TwitterController do

end
