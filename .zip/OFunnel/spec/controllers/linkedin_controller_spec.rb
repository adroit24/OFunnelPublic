require 'spec_helper'

describe LinkedinController do

end
