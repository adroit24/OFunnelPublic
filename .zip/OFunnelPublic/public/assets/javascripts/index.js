var nameError,emailError = true;
$(document).ready(function(){
    if(location.href.match('signup-error')) {
        $("div#signup-error").fadeIn();
    }

    $("#close-error").click(function(){
        $("#signup-error").fadeOut();
    });

    $("#close").click(function(){
        $("#thankyou").fadeOut();
    });

    $("div.mobile-top-menu").click(function() {
        $('ul.menu-list-box').show();
        $('div.mobile-top-menu').removeClass('mobile-top-normal');
        $('div.mobile-top-menu').addClass('mobile-top-hover');
    });

    $(document).mouseup(function (e)
    {
        var container = $("div.mobile-top-menu");

        if (container.has(e.target).length === 0)
        {
            $('ul.menu-list-box').hide();
            $('div.mobile-top-menu').removeClass('mobile-top-hover');
            $('div.mobile-top-menu').addClass('mobile-top-normal');
        }
    });

    $('form.signup-submit').click(function(event) {
        var userName = $('form.signup-submit').find('input[name=userName]').val();
        var email = $('form.signup-submit').find('input[name=email]').val();
        if (userName.match(/\S/)) {
            $('span#web-name-error').hide();
            nameError = true;
        }
        else {
            $('span#web-name-error').show();
            nameError = false;
        }
        if(email.match(/\S/) && email.match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/)) {
            $('span#web-email-error').hide();
            emailError = true;
        }
        else {
            $('span#web-email-error').show();
            emailError = false;
        }
        if(nameError && emailError) {
            $.ajax({
                type: "POST",
                async: false,
                url: 'http://ofunnelservice.cloudapp.net/OFunnelService/UserService.svc/addSignUpUser',
                data: $(this).serialize(),
                success: function(result) {
                    console.log(result);
                },
                error: function(error) {
                    console.log(error);
                }
            });
            $('input.input').val("");
            $("#thankyou").fadeIn();
        }
        return false;
    });

    $('form.signup-submit-mobile').click(function(event) {
        var userName = $('form.signup-submit-mobile').find('input[name=userName]').val();
        var email = $('form.signup-submit-mobile').find('input[name=email]').val();
        if (userName.match(/\S/)) {
            $('span#mobile-name-error').hide();
            nameError = true;
        }
        else {
            $('span#mobile-name-error').show();
            nameError = false;
        }
        if(email.match(/\S/) && email.match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/)) {
            $('span#mobile-email-error').hide();
            emailError = true;
        }
        else {
            $('span#mobile-email-error').show();
            emailError = false;
        }
        if(nameError && emailError) {
            $.ajax({
                type: "POST",
                async: false,
                url: 'http://ofunnelservice.cloudapp.net/OFunnelService/UserService.svc/addSignUpUser',
                data: $(this).serialize(),
                success: function(result) {
                    console.log(result);
                },
                error: function(error) {
                    console.log(error);
                }
            });
            $('input.input').val("");
            $("#thankyou").fadeIn();
        }
        return false;
    });
});
